﻿namespace Sitecore.RedirectionManager.RedirectionObject
{
    public class RedirectUrlObject
    {
        public string AcientUrl { get; set; }

        public string NewUrl { get; set; }

        public string IgnoreUrl { get; set; }
    }
}
